import {
  CHROME_UA,
  getCookiesFromHeaders,
  serializeData,
  cleanUrl,
} from "../utils/index.js";
import { scraperFetch, createScraperResult } from "./httpHelper.js";

export let _spSource = null;
export function setSpotifySource(source) {
  _spSource = source;
}

// Helper: Resolve Spotify Short Links (spotify.link / spotify.com/s/...)
async function resolveSpotifyLink(url) {
  let target = url.trim();
  if (target.match(/spotify\.com\/s\//i) || target.match(/spotify\.link\//i)) {
    try {
      const resolveRes = await scraperFetch(
        {
          url: target,
          headers: { "User-Agent": "WhatsApp/2.21.19.21 A" },
          rawResponse: true,
        },
        "Spotify Link Resolver",
      );
      if (resolveRes) {
        if (resolveRes.url && !resolveRes.url.match(/(spotify\.com\/s\/|spotify\.link)/i)) {
          target = cleanUrl(resolveRes.url);
        } else if (resolveRes.data) {
          const htmlData =
            typeof resolveRes.data === "string"
              ? resolveRes.data
              : JSON.stringify(resolveRes.data);
          const ogMatch = htmlData.match(/<meta property="og:url" content="([^"]+)"/i);
          if (ogMatch && ogMatch[1]) {
            target = cleanUrl(ogMatch[1]);
          } else {
            const schemeMatch = htmlData.match(/<script id="urlSchemeConfig" type="text\/plain">([^<]+)<\/script>/);
            if (schemeMatch && schemeMatch[1]) {
              try {
                let b64 = schemeMatch[1];
                b64 = b64.padEnd(b64.length + ((4 - (b64.length % 4)) % 4), "=");
                const decoded = JSON.parse(atob(b64));
                if (decoded && decoded.redirectUrl) {
                  target = cleanUrl(decoded.redirectUrl);
                }
              } catch (_) {}
            }
          }
        }
      }
    } catch (e) {
      console.warn("Failed to resolve Spotify short link:", e);
    }
  }
  return target.split("?")[0];
}

// Helper: Build Multipart Form Data
function createMultipartFormData(fields) {
  const boundary = "----WebKitFormBoundary" + Math.random().toString(36).substring(2);
  let body = "";
  for (const [k, v] of Object.entries(fields)) {
    if (v !== undefined && v !== null) {
      body += `--${boundary}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${v}\r\n`;
    }
  }
  body += `--${boundary}--\r\n`;
  return {
    body,
    contentType: `multipart/form-data; boundary=${boundary}`,
  };
}

/**
 * Main Spotify Scraper Entry Point
 */
export async function scrapeSpotify(rawUrl) {
  if (!_spSource) {
    return { status: true, requireSource: true };
  }

  const url = await resolveSpotifyLink(rawUrl);
  const source = _spSource || "soundloaders";
  _spSource = null;

  // Execution order with automatic failover
  const engines = [];
  if (source === "spotidown") {
    engines.push(scrapeSpotidownEngine, scrapeSpotimateEngine, scrapeSpotisaverEngine);
  } else if (source === "spotisaver") {
    engines.push(scrapeSpotisaverEngine, scrapeSpotimateEngine, scrapeSpotidownEngine);
  } else {
    // Default / soundloaders / spotmate
    engines.push(scrapeSpotimateEngine, scrapeSpotidownEngine, scrapeSpotisaverEngine);
  }

  let lastError = null;
  for (const engine of engines) {
    try {
      const res = await engine(url);
      if (res && res.status) return res;
    } catch (err) {
      lastError = err;
      console.warn(`[Spotify] Engine failed, trying backup:`, err.message);
    }
  }

  return createScraperResult(false, `Spotify error: ${lastError?.message || "Failed to extract Spotify media"}`);
}

/**
 * Engine 1: SoundLoaders / SpotMate (https://spotimate.app)
 */
async function scrapeSpotimateEngine(url) {
  const BASE = "https://spotimate.app";
  const cleanTrackUrl = url.split("?")[0];

  // 1. Get initial session cookies
  const r1 = await scraperFetch(
    {
      url: BASE + "/en1",
      headers: {
        "User-Agent": CHROME_UA,
        Accept: "*/*",
      },
      rawResponse: true,
    },
    "Spotimate Home",
  );
  let cookies = getCookiesFromHeaders(r1.headers) || "";

  // 2. User verification token
  let token = "";
  try {
    const vRes = await scraperFetch(
      {
        url: BASE + "/api/userverify",
        method: "POST",
        data: `url=${encodeURIComponent(cleanTrackUrl)}`,
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          "User-Agent": CHROME_UA,
          "X-Requested-With": "XMLHttpRequest",
          Referer: BASE + "/en1",
          Origin: BASE,
          Cookie: cookies,
        },
        rawResponse: true,
      },
      "Spotimate Verify",
    );
    const vCookies = getCookiesFromHeaders(vRes.headers);
    if (vCookies) cookies = cookies ? `${cookies}; ${vCookies}` : vCookies;

    let vData = vRes.data;
    if (typeof vData === "string") {
      try { vData = JSON.parse(vData); } catch (_) {}
    }
    if (vData?.success && vData?.token) token = vData.token;
  } catch (_) {}

  // 3. Action Request (Multipart)
  const mp = createMultipartFormData({ url: cleanTrackUrl, cftoken: token });
  const actRes = await scraperFetch(
    {
      url: BASE + "/action",
      method: "POST",
      data: mp.body,
      headers: {
        "Content-Type": mp.contentType,
        "User-Agent": CHROME_UA,
        Referer: BASE + "/en1",
        Origin: BASE,
        Cookie: cookies,
      },
      rawResponse: true,
    },
    "Spotimate Action",
  );

  const actCookies = getCookiesFromHeaders(actRes.headers);
  if (actCookies) cookies = cookies ? `${cookies}; ${actCookies}` : actCookies;

  let actData = actRes.data;
  if (typeof actData === "string") {
    try { actData = JSON.parse(actData); } catch (_) {}
  }
  const html = actData?.html || (typeof actData === "string" ? actData : "");
  if (!html || html.length < 50) {
    throw new Error(actData?.message || actData?.error || "Invalid response from Spotimate.");
  }

  // Parse tracks from returned HTML
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  const forms = doc.querySelectorAll('form[name="submitapurl"], form[name="submitspurl"], form[name="submiturl"]');

  if (!forms.length) {
    throw new Error("No tracks found for this Spotify link on Spotimate.");
  }

  const isMultiTrack = forms.length > 1;
  const downloads = [];
  let mainTitle = doc.querySelector("h3")?.textContent?.trim() || "";
  let mainArtist = doc.querySelector("p")?.textContent?.trim() || "";
  let mainThumb = doc.querySelector("img")?.getAttribute("src") || "";

  for (let i = 0; i < forms.length; i++) {
    const f = forms[i];
    const dataVal = f.querySelector('input[name="data"]')?.value || "";
    const baseVal = f.querySelector('input[name="base"]')?.value || cleanTrackUrl;
    const tokenVal = f.querySelector('input[name="token"]')?.value || "";

    let trackMeta = {};
    if (dataVal) {
      try {
        trackMeta = JSON.parse(atob(dataVal));
      } catch (_) {}
    }

    const trackName = trackMeta.name || trackMeta.title || `Track ${i + 1}`;
    const trackArtist = trackMeta.artist || trackMeta.singer || mainArtist || "";
    const trackThumb = trackMeta.cover || mainThumb;
    const fullLabel = trackArtist ? `${trackArtist} - ${trackName}` : trackName;

    const prefix = isMultiTrack
      ? `${(i + 1).toString().padStart(String(forms.length).length, "0")}. `
      : "";

    // For single track, resolve download link directly
    if (i === 0 && !isMultiTrack) {
      try {
        const payload = serializeData({
          data: dataVal,
          base: baseVal,
          token: tokenVal,
          "g-recaptcha-response": "dummy_token",
        });

        const trRes = await scraperFetch(
          {
            url: BASE + "/action/track",
            method: "POST",
            data: payload,
            headers: {
              "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
              "User-Agent": CHROME_UA,
              "X-Requested-With": "XMLHttpRequest",
              Referer: BASE + "/en1",
              Origin: BASE,
              Cookie: cookies,
            },
            rawResponse: true,
          },
          "Spotimate Track Resolve",
        );

        let trData = trRes.data;
        if (typeof trData === "string") {
          try { trData = JSON.parse(trData); } catch (_) {}
        }
        const trHtml = trData?.data || trData?.html || (typeof trData === "string" ? trData : "");
        const trDoc = parser.parseFromString(trHtml, "text/html");

        let foundMp3 = null;
        let foundCover = null;
        trDoc.querySelectorAll("a").forEach((a) => {
          const href = a.getAttribute("href");
          const text = (a.textContent || "").trim();
          if (
            href &&
            href.startsWith("http") &&
            !href.includes("premium.html") &&
            !text.toLowerCase().includes("another song")
          ) {
            const isCover = text.toLowerCase().includes("cover") || href.includes("cover") || href.includes("i.scdn.co") || /\.(jpg|jpeg|png|webp)($|\?)/i.test(href);
            if (isCover) {
              if (!foundCover) foundCover = href;
            } else {
              if (!foundMp3) foundMp3 = href;
            }
          }
        });

        if (foundMp3) {
          downloads.push({
            type: `${fullLabel} [MP3]`,
            title: fullLabel,
            name: fullLabel,
            quality: "320kbps",
            thumbnail: trackThumb,
            url: foundMp3,
          });
        }
        if (foundCover) {
          downloads.push({
            type: `${fullLabel} [Cover]`,
            title: fullLabel,
            name: fullLabel,
            quality: "Cover [HD]",
            thumbnail: trackThumb,
            url: foundCover,
          });
        }
      } catch (e) {
        console.warn("Spotimate single track direct fetch failed:", e);
      }
    }

    // Add lazy resolve link for playlist/album items or single-track fallback
    if (downloads.length === 0 || isMultiTrack) {
      downloads.push({
        type: `${prefix}${fullLabel} [MP3]`,
        title: fullLabel,
        name: fullLabel,
        quality: "320kbps",
        thumbnail: trackThumb,
        url: `soundloaders_resolve:${dataVal}|||${tokenVal}|||${encodeURIComponent(baseVal)}|||${encodeURIComponent(cookies)}`,
      });
    }
  }

  if (downloads.length === 0) {
    throw new Error("Failed to extract Spotify download links from Spotimate.");
  }

  // Sanitize title from promo text
  if (/zip/i.test(mainTitle) || /your free/i.test(mainTitle) || !mainTitle) {
    mainTitle = downloads[0]?.title || downloads[0]?.name || "Spotify Album";
  }

  const finalTitle = mainArtist && !mainTitle.includes(mainArtist)
    ? `${mainArtist} - ${mainTitle}`
    : mainTitle;

  return createScraperResult(true, {
    title: isMultiTrack ? `${finalTitle} (${forms.length} tracks)` : finalTitle,
    thumbnail: mainThumb || downloads[0]?.thumbnail,
    downloads,
    sourceUrl: url,
  });
}

/**
 * Engine 2: SpotiDown (https://spotidown.app)
 */
async function scrapeSpotidownEngine(url) {
  const BASE = "https://spotidown.app";
  const cleanTrackUrl = url.split("?")[0];

  const r1 = await scraperFetch(
    {
      url: BASE + "/en7",
      headers: {
        "User-Agent": CHROME_UA,
        Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
      },
      rawResponse: true,
    },
    "SpotiDown Home",
  );

  let currentCookies = getCookiesFromHeaders(r1.headers) || "";

  const r2Headers = {
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "User-Agent": CHROME_UA,
    Origin: BASE,
    Referer: BASE + "/en7",
    "X-Requested-With": "XMLHttpRequest",
  };
  if (currentCookies) r2Headers["Cookie"] = currentCookies;

  const r2 = await scraperFetch(
    {
      url: BASE + "/action",
      method: "POST",
      data: serializeData({
        url: cleanTrackUrl,
        "g-recaptcha-response": "dummy_token",
      }),
      headers: r2Headers,
      rawResponse: true,
    },
    "SpotiDown Action",
  );

  const moreCookies = getCookiesFromHeaders(r2.headers);
  if (moreCookies) {
    currentCookies = currentCookies ? `${currentCookies}; ${moreCookies}` : moreCookies;
  }

  let r2Data = r2.data;
  if (typeof r2Data === "string") {
    try { r2Data = JSON.parse(r2Data); } catch (_) {}
  }
  if (!r2Data || r2Data.error) {
    throw new Error(r2Data?.message || "Failed to process Spotify URL on SpotiDown.");
  }

  const parser = new DOMParser();
  const doc = parser.parseFromString(r2Data.data || r2Data, "text/html");
  const forms = doc.querySelectorAll('form[name="submitspurl"]');

  if (!forms.length) {
    throw new Error("No tracks found for this Spotify link on SpotiDown.");
  }

  const isMultiTrack = forms.length > 1;
  const downloads = [];

  for (let i = 0; i < forms.length; i++) {
    const f = forms[i];
    const dataVal = f.querySelector('input[name="data"]')?.value || "";
    const baseVal = f.querySelector('input[name="base"]')?.value || cleanTrackUrl;
    const tokenVal = f.querySelector('input[name="token"]')?.value || "";

    let meta = {};
    if (dataVal) {
      try {
        meta = JSON.parse(atob(dataVal));
      } catch (_) {}
    }

    const name = meta.name || meta.title || "Spotify Track";
    const artist = meta.artist || meta.singer || "";
    const thumb = meta.cover || "";
    const fullLabel = artist ? `${artist} - ${name}` : name;
    const prefix = isMultiTrack
      ? `${(i + 1).toString().padStart(String(forms.length).length, "0")}. `
      : "";

    const payloadStr = serializeData({
      data: dataVal,
      base: baseVal,
      token: tokenVal,
      "g-recaptcha-response": "dummy_token",
    });

    if (i === 0 && !isMultiTrack) {
      try {
        const r3 = await scraperFetch(
          {
            url: BASE + "/action/track",
            method: "POST",
            data: payloadStr,
            headers: {
              ...r2Headers,
              Cookie: currentCookies,
            },
            rawResponse: true,
          },
          "SpotiDown Track",
        );

        let r3Data = r3.data;
        if (typeof r3Data === "string") {
          try { r3Data = JSON.parse(r3Data); } catch (_) {}
        }
        const trackHtml = r3Data?.data || (typeof r3Data === "string" ? r3Data : "");
        const doc3 = parser.parseFromString(trackHtml, "text/html");

        doc3.querySelectorAll("a").forEach((a) => {
          const link = a.getAttribute("href");
          const text = (a.textContent || "").trim();
          if (
            link &&
            link.startsWith("http") &&
            !link.includes("premium.html") &&
            text !== "Download Another Song"
          ) {
            const isCover = text.toLowerCase().includes("cover") || link.includes("cover");
            downloads.push({
              type: `${prefix}${fullLabel} ${isCover ? "[Cover]" : "[MP3]"}`,
              title: fullLabel,
              name: fullLabel,
              quality: isCover ? "Cover [HD]" : "320kbps",
              url: link,
            });
          }
        });
      } catch (e) {
        console.warn("SpotiDown single track direct fetch failed:", e);
      }
    }

    if (downloads.length === 0 || isMultiTrack) {
      downloads.push({
        type: `${prefix}${fullLabel} [MP3]`,
        title: fullLabel,
        name: fullLabel,
        quality: "320kbps",
        thumbnail: thumb,
        url: `spotidown_resolve:${payloadStr}|||${encodeURIComponent(currentCookies || "")}`,
      });
    }
  }

  if (downloads.length === 0) {
    throw new Error("No download links found from SpotiDown.");
  }

  let title = doc.querySelector("h3")?.textContent?.trim() || "Spotify Track";
  const artist = doc.querySelector("p")?.textContent?.trim();
  const thumbnail = doc.querySelector("img")?.getAttribute("src");

  if (/zip/i.test(title) || /your free/i.test(title)) {
    title = downloads[0]?.title || downloads[0]?.name || "Spotify Album";
  }

  const finalTitle = artist && !title.includes(artist) ? `${artist} - ${title}` : title;

  return createScraperResult(true, {
    title: isMultiTrack ? `${finalTitle} (${forms.length} tracks)` : finalTitle,
    thumbnail,
    downloads,
    sourceUrl: url,
  });
}

/**
 * Engine 3: Spotisaver (https://spotisaver.net)
 */
async function scrapeSpotisaverEngine(url) {
  const BASE = "https://spotisaver.net";
  const match = url.match(/spotify\.com\/(track|album|playlist|artist|show|episode)\/([a-zA-Z0-9]+)/i);
  if (!match) throw new Error("Must be a valid Spotify URL.");

  const type = match[1].toLowerCase();
  const id = match[2];

  const r1 = await scraperFetch(
    {
      url: BASE + "/en1",
      headers: { "User-Agent": CHROME_UA },
      rawResponse: true,
    },
    "Spotisaver Home",
  );

  const cookies = getCookiesFromHeaders(r1.headers) || "";
  const html = typeof r1.data === "string" ? r1.data : "";

  const matchSig = html.match(/playlistRequestSignature\s*=\s*(\{.*?\});/s);
  if (!matchSig) {
    throw new Error("Could not parse signature configuration from Spotisaver.");
  }

  let sigConfig;
  try {
    const cleanJson = matchSig[1]
      .replace(/\/\/.*?\n/g, "")
      .replace(/(\b\w+\b)\s*:/g, '"$1":')
      .replace(/'/g, '"');
    sigConfig = JSON.parse(cleanJson);
  } catch (_) {
    throw new Error("Failed to evaluate Spotisaver signature configuration.");
  }

  const wire = sigConfig.wire || {};
  const ctxObj = { id, type, lang: "en" };
  const b64 = btoa(JSON.stringify(ctxObj))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");

  const sigParams = new URLSearchParams();
  sigParams.set(wire.token_param, sigConfig.requestToken);
  sigParams.set(wire.action_param, wire.actions["get_playlist"]);
  sigParams.set(wire.ctx_param, b64);

  const rSig = await scraperFetch(
    {
      url: `${BASE}${sigConfig.endpoint}?${sigParams.toString()}`,
      headers: {
        "User-Agent": CHROME_UA,
        Accept: "application/json",
        Referer: BASE + "/en1",
        Cookie: cookies,
      },
    },
    "Spotisaver Sig",
  );

  if (!rSig || !rSig.success || !rSig.token) {
    throw new Error("Failed to obtain request signature from Spotisaver.");
  }

  const reqHeaders = {
    "User-Agent": CHROME_UA,
    Accept: "application/json",
    Referer: BASE + "/en1",
    Cookie: cookies,
  };
  reqHeaders[wire.sig_header] = rSig.token;
  reqHeaders[wire.exp_header] = String(rSig.exp);

  const rPlay = await scraperFetch(
    {
      url: `${BASE}/api/get_playlist.php?id=${id}&type=${type}&lang=en`,
      headers: reqHeaders,
    },
    "Spotisaver Playlist",
  );

  if (!rPlay || rPlay.error) {
    throw new Error(rPlay?.error || "Failed to retrieve Spotify data from Spotisaver.");
  }

  const info = rPlay.playlist_info || {};
  const rawTracks = rPlay.tracks || [];
  if (rawTracks.length === 0) {
    throw new Error("No tracks found from Spotisaver.");
  }

  const isMultiTrack = type !== "track" || rawTracks.length > 1;
  const downloads = [];
  const padLen = String(rawTracks.length).length;

  rawTracks.forEach((t, idx) => {
    const artist = t.artists && t.artists.length ? t.artists.join(", ") : info.owner || "";
    const name = t.name || `Track ${idx + 1}`;
    const fullLabel = artist ? `${artist} - ${name}` : name;
    const prefix = isMultiTrack ? `${(idx + 1).toString().padStart(padLen, "0")}. ` : "";
    const thumb = t.image?.url || t.thumb_image?.url || info.images?.[0]?.url || "";

    downloads.push({
      type: `${prefix}${fullLabel} [MP3]`,
      title: fullLabel,
      name: fullLabel,
      quality: "320kbps",
      thumbnail: thumb,
      url: `spotisaver_resolve:${t.id}|||${encodeURIComponent(name)}|||${Math.trunc(t.duration_ms || 0)}|||${encodeURIComponent(cookies)}`,
    });
  });

  const firstTrack = rawTracks[0];
  const albumTitle = info.name || firstTrack.name || "Spotify Album";
  const firstArtist = firstTrack.artists?.join(", ") || info.owner || "";
  const displayTitle = firstArtist ? `${firstArtist} - ${albumTitle}` : albumTitle;
  const thumbUrl = firstTrack.image?.url || info.images?.[0]?.url || "";

  return createScraperResult(true, {
    title: isMultiTrack ? `${displayTitle} (${rawTracks.length} tracks)` : displayTitle,
    thumbnail: thumbUrl,
    downloads,
    sourceUrl: url,
  });
}
