import { getCleanUrl } from "../utils/urlUtils.js";
import { CHROME_DESKTOP_UA, getCookiesFromHeaders } from "../utils/index.js";
import { scraperFetch, createScraperResult } from "./httpHelper.js";

/**
 * Scraper for Shopee Video & Shopee Media
 * Primary: Direct Shopee Video metadata & stream extractor (__NEXT_DATA__ & .vod.susercontent.com)
 * Backup: SVXtract (https://svxtract.com)
 */
export async function scrapeShopee(url) {
  try {
    const urlMatch = url.match(/https?:\/\/[^\s]+/i);
    let cleanUrl = getCleanUrl(urlMatch ? urlMatch[0] : url);

    // 1. Resolve short links (id.shp.ee, shp.ee, etc.) to get the canonical video URL
    if (/shp\.ee/i.test(cleanUrl) || /shopee\.[a-z.]+\/universal-link/i.test(cleanUrl)) {
      try {
        const redirectRes = await scraperFetch(
          {
            url: cleanUrl,
            rawResponse: true,
            headers: {
              "User-Agent": CHROME_DESKTOP_UA,
              Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
              "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
            },
          },
          "Shopee Redirect",
        );

        if (redirectRes.headers?.location || redirectRes.headers?.Location) {
          cleanUrl = redirectRes.headers.location || redirectRes.headers.Location;
        } else if (redirectRes.url && !/shp\.ee/i.test(redirectRes.url)) {
          cleanUrl = redirectRes.url;
        } else if (typeof redirectRes.data === "string") {
          const canonical = redirectRes.data.match(/<link\s+rel=["']canonical["']\s+href=["']([^"']+)["']/i);
          const ogUrl = redirectRes.data.match(/<meta\s+property=["']og:url["']\s+content=["']([^"']+)["']/i);
          const redirMatch = redirectRes.data.match(/redir=([^"'\s&]+)/i);

          if (canonical && canonical[1] && !canonical[1].includes("icon")) {
            cleanUrl = canonical[1];
          } else if (ogUrl && ogUrl[1]) {
            cleanUrl = ogUrl[1];
          } else if (redirMatch) {
            cleanUrl = decodeURIComponent(redirMatch[1]).replace(/&amp;/g, "&");
          }
        }
      } catch (e) {
        console.warn("Shopee redirect resolve failed:", e);
      }
    }

    if (cleanUrl.includes("redir=")) {
      try {
        const parsed = new URL(cleanUrl);
        const redir = parsed.searchParams.get("redir");
        if (redir) cleanUrl = redir;
      } catch (_) {}
    }

    // 2. PRIMARY ENGINE: Direct Shopee Video & HTML Crawler
    try {
      const directRes = await scraperFetch(
        {
          url: cleanUrl,
          rawResponse: true,
          parseJson: false,
          headers: {
            "User-Agent": CHROME_DESKTOP_UA,
            Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
          },
        },
        "Shopee Direct Page",
      );

      const htmlStr = typeof directRes.data === "string" ? directRes.data : "";

      if (htmlStr) {
        // High-precision extraction from __NEXT_DATA__
        const nextDataMatch = htmlStr.match(/<script\s+id=["']__NEXT_DATA__["']\s+type=["']application\/json["']>([\s\S]*?)<\/script>/i);
        if (nextDataMatch) {
          try {
            const nextData = JSON.parse(nextDataMatch[1]);
            const pageProps = nextData.props?.pageProps;
            const mediaInfo = pageProps?.mediaInfo || {};
            const video = mediaInfo.video || {};
            const userInfo = mediaInfo.userInfo || {};

            const watermarkUrl = video.watermarkVideoUrl || video.videoUrl;
            let noWmDefault = null;
            let noWmMaster = null;

            if (video.videoUrl && video.videoUrl !== video.watermarkVideoUrl) {
              noWmDefault = video.videoUrl;
            }

            if (watermarkUrl) {
              if (/\.\d+\.\d+\.mp4/i.test(watermarkUrl)) {
                noWmDefault = noWmDefault || watermarkUrl.replace(/\.\d+\.\d+\.mp4/i, ".default.mp4");
                noWmMaster = watermarkUrl.replace(/\.\d+\.\d+\.mp4/i, ".mp4");
              } else if (/\.\d+\.mp4/i.test(watermarkUrl)) {
                noWmDefault = noWmDefault || watermarkUrl.replace(/\.\d+\.mp4/i, ".default.mp4");
                noWmMaster = watermarkUrl.replace(/\.\d+\.mp4/i, ".mp4");
              }
            }

            if (watermarkUrl || noWmDefault) {
              const username = userInfo.videoUserName || "Shopee Creator";
              const title = video.caption || `${username} on Shopee Video`;
              const author = username;
              let thumbnail = video.coverUrl || video.watermarkCoverUrl || video.watermarkShareImageUrl;
              if (thumbnail && thumbnail.includes("@imgwm_")) {
                thumbnail = thumbnail.split("@imgwm_")[0];
              }

              const downloads = [];
              if (noWmDefault) {
                downloads.push({
                  url: noWmDefault,
                  type: "VIDEO",
                  quality: "HD Video (Tanpa Watermark)",
                });
              }
              if (noWmMaster && noWmMaster !== noWmDefault) {
                downloads.push({
                  url: noWmMaster,
                  type: "VIDEO",
                  quality: "Kualitas Asli Master (Tanpa Watermark)",
                });
              }
              if (watermarkUrl && (!noWmDefault || watermarkUrl !== noWmDefault)) {
                downloads.push({
                  url: watermarkUrl,
                  type: "VIDEO",
                  quality: "Video (Dengan Watermark)",
                });
              }

              return createScraperResult(true, {
                title,
                description: video.caption || "",
                author,
                thumbnail,
                downloads,
                sourceUrl: url,
              });
            }
          } catch (e) {
            console.warn("Failed parsing Shopee __NEXT_DATA__:", e);
          }
        }

        // Fallback HTML regex extraction
        const titleMatch = htmlStr.match(/<title>([^<]+)<\/title>/i);
        let title = titleMatch ? titleMatch[1].replace(/\s*\|\s*Shopee.*$/i, "").trim() : "Shopee Video";

        const descMatch =
          htmlStr.match(/<meta\s+property=["']og:description["']\s+content=["']([^"']+)["']/i) ||
          htmlStr.match(/<meta\s+name=["']description["']\s+content=["']([^"']+)["']/i);
        let description = descMatch ? descMatch[1] : "";
        description = description
          .replace(/&amp;/g, "&")
          .replace(/&#x27;/g, "'")
          .replace(/&quot;/g, '"')
          .trim();

        let author = "Shopee Creator";
        const authorMatch = title.match(/^([^\s]+)\s+on\s+Shopee/i);
        if (authorMatch) {
          author = authorMatch[1];
        } else if (description.includes("watch @")) {
          const atMatch = description.match(/watch\s+@([^\s']+)/i);
          if (atMatch) author = atMatch[1];
        }

        const thumbMatch =
          htmlStr.match(/<meta\s+property=["']og:image["']\s+content=["']([^"']+)["']/i) ||
          htmlStr.match(/<meta\s+name=["']twitter:image["']\s+content=["']([^"']+)["']/i) ||
          htmlStr.match(/https?:\/\/[^\s"']+\.susercontent\.com\/[^\s"']+/i);
        let thumbnail = thumbMatch ? (thumbMatch[1] || thumbMatch[0]) : null;
        if (thumbnail && thumbnail.includes("@imgwm_")) {
          thumbnail = thumbnail.split("@imgwm_")[0];
        }

        const downloads = [];
        const seenUrls = new Set();
        const videoMatches = [
          ...(htmlStr.matchAll(/https?:\/\/[^\s"']+\.vod\.susercontent\.com\/[^\s"']+\.mp4/gi) || []),
          ...(htmlStr.matchAll(/https?:\\\/\\\/[^\s"']+\.vod\.susercontent\.com\\\/[^\s"']+\.mp4/gi) || []),
          ...(htmlStr.matchAll(/<meta\s+property=["']og:video(?::url)?["']\s+content=["']([^"']+)["']/gi) || []),
        ];

        for (const rawMatch of videoMatches) {
          let vUrl = (rawMatch[1] || rawMatch[0]).replace(/\\\//g, "/");
          if (!vUrl || !vUrl.startsWith("http")) continue;

          if (/\.\d+\.\d+\.mp4/i.test(vUrl)) {
            const noWm = vUrl.replace(/\.\d+\.\d+\.mp4/i, ".default.mp4");
            const noWmMaster = vUrl.replace(/\.\d+\.\d+\.mp4/i, ".mp4");
            if (!seenUrls.has(noWm)) {
              seenUrls.add(noWm);
              downloads.push({
                url: noWm,
                type: "VIDEO",
                quality: "HD Video (Tanpa Watermark)",
              });
            }
            if (!seenUrls.has(noWmMaster)) {
              seenUrls.add(noWmMaster);
              downloads.push({
                url: noWmMaster,
                type: "VIDEO",
                quality: "Kualitas Asli Master (Tanpa Watermark)",
              });
            }
          }

          if (!seenUrls.has(vUrl)) {
            seenUrls.add(vUrl);
            downloads.push({
              url: vUrl,
              type: "VIDEO",
              quality: downloads.length === 0 ? "HD Video (Tanpa Watermark)" : "Video (Dengan Watermark)",
            });
          }
        }

        if (downloads.length > 0) {
          return createScraperResult(true, {
            title,
            description,
            author,
            thumbnail,
            downloads,
            sourceUrl: url,
          });
        }
      }
    } catch (directErr) {
      console.warn("Direct Shopee video crawler failed:", directErr.message);
    }

    // 3. BACKUP ENGINE: SVXtract (https://svxtract.com)
    const urlsToTrySvxtract = [cleanUrl, url];
    for (const targetUrl of urlsToTrySvxtract) {
      try {
        const homeRes = await scraperFetch(
          {
            url: "https://svxtract.com/",
            rawResponse: true,
            headers: {
              "User-Agent": CHROME_DESKTOP_UA,
              Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
              "Accept-Language": "en-US,en;q=0.9",
            },
          },
          "SVXtract Session",
        );

        const html = typeof homeRes.data === "string" ? homeRes.data : "";
        const cookie = getCookiesFromHeaders(homeRes.headers || {});

        const csrfMatch =
          html.match(/encodeURIComponent\(["']([a-f0-9]{32,64})["']\)/i) ||
          html.match(/csrf_token["']?\s*:\s*["']([^"']+)["']/i) ||
          html.match(/csrf_token=([^&"'\s]+)/i);

        const csrfToken = csrfMatch ? csrfMatch[1] : null;

        if (csrfToken) {
          const apiUrl = `https://svxtract.com/apiv3.php?url=${encodeURIComponent(targetUrl)}&csrf_token=${encodeURIComponent(csrfToken)}`;

          const apiRes = await scraperFetch(
            {
              url: apiUrl,
              headers: {
                "User-Agent": CHROME_DESKTOP_UA,
                Referer: "https://svxtract.com/",
                Origin: "https://svxtract.com",
                Cookie: cookie,
                Accept: "application/json, text/javascript, */*; q=0.01",
                "X-Requested-With": "XMLHttpRequest",
              },
            },
            "SVXtract API",
          );

          let resData = apiRes;
          if (typeof resData === "string") {
            try { resData = JSON.parse(resData); } catch (_) {}
          }

          if (resData && resData.stream) {
            const username = resData.username || "Shopee Creator";
            const title = `${username} on Shopee Video`;
            const thumbnail = resData.preview || null;
            const downloads = [];

            const streamKeys = Object.keys(resData.stream);
            streamKeys.forEach((key) => {
              const item = resData.stream[key];
              const streamUrl = typeof item === "object" ? item.stream : item;
              if (streamUrl && streamUrl.startsWith("http")) {
                downloads.push({
                  url: streamUrl,
                  type: "VIDEO",
                  quality: `${key} (No Watermark)`,
                  headers: {
                    Referer: "https://svxtract.com/",
                    "User-Agent": CHROME_DESKTOP_UA,
                  },
                });
              }
            });

            if (downloads.length > 0) {
              return createScraperResult(true, {
                title,
                description: `Shopee Video by @${username}`,
                author: username,
                thumbnail,
                downloads,
                sourceUrl: url,
              });
            }
          }
        }
      } catch (svErr) {
        console.warn("SVXtract attempt failed for", targetUrl, svErr.message);
      }
    }

    throw new Error("No Shopee Video media found or link is private/expired.");
  } catch (e) {
    return createScraperResult(false, e.message);
  }
}
