import { scraperFetch, createScraperResult } from "./httpHelper.js";

function decodeHtmlEntities(str) {
  if (!str) return "";
  return str
    .replace(/&#064;/g, "@")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

export async function scrapeThreads(url) {
  try {
    let cleanUrl = (url || "").trim();

    // 1. Resolve redirect for share URLs (e.g., https://www.threads.com/share/BBQpGJ4xyt/)
    let resolvedPostUrl = cleanUrl;
    if (cleanUrl.includes("/share/")) {
      try {
        const resolveRes = await scraperFetch(
          {
            url: cleanUrl,
            headers: {
              "User-Agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
              Accept:
                "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            },
            rawResponse: true,
          },
          "Threads Link Resolver",
        );
        if (resolveRes?.headers?.location) {
          resolvedPostUrl = resolveRes.headers.location;
        }
      } catch (e) {
        console.warn("[Threads] Share link resolve warning:", e);
      }
    }

    // 2. Normalize domain to threads.net for downstream scraper compatibility
    const targetUrl = resolvedPostUrl.replace(/threads\.com/i, "threads.net");

    // 3. Fetch threadster session cookie
    const mainRes = await scraperFetch(
      {
        url: "https://threadster.app/",
        rawResponse: true,
      },
      "Threadster Main",
    );
    
    let cookies = "";
    if (mainRes?.headers) {
      const rawCookie = mainRes.headers["set-cookie"] || mainRes.headers["Set-Cookie"] || "";
      if (Array.isArray(rawCookie)) {
        cookies = rawCookie.map((c) => c.split(";")[0]).join("; ");
      } else if (typeof rawCookie === "string") {
        cookies = rawCookie.split(";")[0];
      }
    }

    // 4. Request download links from Threadster
    const html = await scraperFetch(
      {
        url: "https://threadster.app/download",
        method: "POST",
        data: { url: targetUrl },
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Cookie: cookies,
          Origin: "https://threadster.app",
          Referer: "https://threadster.app/",
        },
        parseJson: false,
      },
      "Threadster Download",
    );

    const parser = new DOMParser();
    const doc = parser.parseFromString(html, "text/html");
    const downloads = [];
    const seenUrls = new Set();

    // Extract title & description if present in response
    let extractedTitle = "";
    const cardTitle = doc.querySelector(".card-title, .video-title, h1, h2, h3, p");
    if (cardTitle && cardTitle.textContent) {
      extractedTitle = cardTitle.textContent.trim();
    }

    // Parse all download token links
    doc.querySelectorAll("a").forEach((a) => {
      const href = a.getAttribute("href");
      if (href && (href.includes("token=") || href.includes("acxcdn.com"))) {
        let finalUrl = href;
        let type = "VIDEO";
        try {
          const urlObj = new URL(href);
          const token = urlObj.searchParams.get("token");
          if (token) {
            const payloadPart = token.split(".")[1];
            if (payloadPart) {
              let b64 = payloadPart.replace(/-/g, "+").replace(/_/g, "/");
              while (b64.length % 4) b64 += "=";
              const payload = JSON.parse(atob(b64));
              if (payload.url) {
                finalUrl = payload.url;
                const lowerUrl = finalUrl.toLowerCase();
                if (
                  lowerUrl.includes(".jpg") ||
                  lowerUrl.includes(".jpeg") ||
                  lowerUrl.includes(".png") ||
                  lowerUrl.includes(".webp")
                ) {
                  type = "IMAGE";
                }
              }
            }
          }
        } catch (e) {}

        if (finalUrl && !seenUrls.has(finalUrl)) {
          seenUrls.add(finalUrl);
          const quality =
            type === "IMAGE"
              ? `HD Photo ${downloads.length + 1}`
              : `HD Video ${downloads.length + 1}`;
          downloads.push({
            type,
            quality,
            url: finalUrl,
            thumbnail: finalUrl,
          });
        }
      }
    });

    // Fallback: If no links from Threadster, attempt direct OpenGraph metadata extraction
    if (downloads.length === 0) {
      try {
        const ogRes = await scraperFetch(
          {
            url: resolvedPostUrl,
            headers: {
              "User-Agent":
                "facebookexternalhit/1.1 (+http://www.facebook.com/externalhit_uatext.php)",
              Accept:
                "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            },
            rawResponse: true,
          },
          "Threads OG Fetch",
        );
        const ogHtml = ogRes?.data || "";
        const ogDesc = ogHtml.match(
          /<meta\s+property=["']og:description["']\s+content=["']([^"']*)["']/i,
        );
        const ogTitle = ogHtml.match(
          /<meta\s+property=["']og:title["']\s+content=["']([^"']*)["']/i,
        );
        const ogImg = ogHtml.match(
          /<meta\s+property=["']og:image["']\s+content=["']([^"']*)["']/i,
        );
        const ogVid = ogHtml.match(
          /<meta\s+property=["']og:video(?::url)?["']\s+content=["']([^"']*)["']/i,
        );

        if (ogDesc && ogDesc[1]) extractedTitle = decodeHtmlEntities(ogDesc[1]).trim();
        else if (ogTitle && ogTitle[1]) extractedTitle = decodeHtmlEntities(ogTitle[1]).trim();

        const imgUrl = ogImg ? decodeHtmlEntities(ogImg[1]).trim() : "";
        const vidUrl = ogVid ? decodeHtmlEntities(ogVid[1]).trim() : "";

        if (vidUrl) {
          downloads.push({
            type: "VIDEO",
            quality: "HD Video",
            url: vidUrl,
            thumbnail: imgUrl || vidUrl,
          });
        } else if (imgUrl) {
          downloads.push({
            type: "IMAGE",
            quality: "HD Photo",
            url: imgUrl,
            thumbnail: imgUrl,
          });
        }
      } catch (ogErr) {
        console.warn("[Threads] OG fallback warning:", ogErr);
      }
    }

    if (downloads.length === 0) {
      throw new Error("No download links found for this Threads post.");
    }

    const finalTitle = extractedTitle || "Threads Content";

    return createScraperResult(true, {
      title: finalTitle,
      description: extractedTitle,
      thumbnail: downloads[0]?.thumbnail || "",
      downloads,
      sourceUrl: cleanUrl,
    });
  } catch (e) {
    return createScraperResult(false, e.message || "Scraping Threads failed.");
  }
}

