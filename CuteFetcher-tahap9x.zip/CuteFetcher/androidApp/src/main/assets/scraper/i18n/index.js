// Stub ringan: utils/index.js mengimpor "translations" hanya untuk teks toast UI.
// Scraper tidak memakainya, jadi file 246 KB aslinya tidak perlu dimuat.
export const translations = { en: {}, id: {} };
