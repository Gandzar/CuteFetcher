// Cute Fetcher: penghubung Kotlin <-> scraper Nimiyo asli (GPL-3.0, lihat NOTICE.md). Disalin dari Musikku host.js.
// Alurnya disalin dari share.js Nimiyo: deteksi platform -> coba server berurutan (fallback chain).
import "./scrapers/index.js"; // memasang window.nimiyoEngine
import { resolveDownloadUrl } from "./resolver.js";

// Pemetaan domain -> platform (dari share.js Nimiyo)
const platformMapping = {
  youtube: /(youtube\.com|youtu\.be)/i,
  tiktok: /(tiktok\.com)/i,
  instagram: /(instagram\.com)/i,
  twitter: /(twitter\.com|x\.com)/i,
  spotify: /(spotify\.com)/i,
  applemusic: /(music\.apple\.com)/i,
  soundcloud: /(soundcloud\.com|on\.soundcloud\.com)/i,
  facebook: /(facebook\.com|fb\.watch|fb\.com)/i,
  threads: /(threads\.(?:net|com))/i,
  pinterest: /(pinterest\.com|pin\.it)/i,
  bilibili: /(bilibili\.com|b23\.tv)/i,
  douyin: /(douyin\.com)/i,
  bandcamp: /(bandcamp\.com)/i,
  pixiv: /(pixiv\.net|pixiv\.me|pximg\.net)/i,
  rednote: /(rednote\.com|xiaohongshu\.com|xhslink\.com|xhslink\.cn)/i,
  shopee: /(shopee\.[a-z.]+|shp\.ee)/i,
};

// Urutan server cadangan per platform (dari share.js Nimiyo)
const fallbackChains = {
  tiktok: ["tiktokio", "snaptik", "ssstik", "tikdownloader", "direct"],
  instagram: ["snapsave", "indown", "direct"],
  facebook: ["snapsave", "direct"],
  spotify: ["soundloaders", "spotidown", "spotisaver", "direct"],
  soundcloud: ["forhub", "klickaud", "direct"],
  twitter: ["direct", "tweeload", "tvd"],
  youtube: ["auto", "gg", "mobi", "direct"],
  applemusic: ["aplmate", "direct"],
  pinterest: ["pindown", "direct"],
  threads: ["threadster", "direct"],
  bilibili: ["direct"],
  douyin: ["direct"],
  bandcamp: ["bandcampdownloader", "direct"],
  pixiv: ["direct"],
  rednote: ["direct"],
  shopee: ["direct", "svxtract"],
};

function detectPlatform(url) {
  if (!url) return null;
  return Object.keys(platformMapping).find((k) => platformMapping[k].test(url)) || null;
}

// Kirim hasil kembali ke Kotlin (objek JavascriptInterface "CuteNative")
function reply(reqId, payload) {
  window.CuteNative.onResult(reqId, JSON.stringify(payload));
}

async function scrape(reqId, url) {
  const platform = detectPlatform(url);
  if (!platform) return reply(reqId, { ok: false, message: "Tautan belum didukung." });

  const failures = [];
  for (const method of fallbackChains[platform] || ["direct"]) {
    try {
      const mod = window.nimiyoEngine?.[platform];
      const fn = mod?.[method] || mod?.default;
      if (!fn) continue;
      const res = await fn(url);
      if (res && res.status === true && res.result) {
        return reply(reqId, { ok: true, platform, result: res.result });
      }
      failures.push(`${method}: ${res?.message || "gagal"}`);
    } catch (e) {
      failures.push(`${method}: ${e?.message || e}`);
    }
  }
  reply(reqId, { ok: false, message: failures.join("\n") || "Semua server gagal." });
}

async function resolve(reqId, itemJson) {
  try {
    const out = await resolveDownloadUrl(JSON.parse(itemJson));
    reply(reqId, { ok: true, ...out });
  } catch (e) {
    reply(reqId, { ok: false, message: e?.message || String(e) });
  }
}

window.CuteHost = { scrape, resolve };
window.CuteNative.onReady(); // beri tahu Kotlin bahwa host siap
