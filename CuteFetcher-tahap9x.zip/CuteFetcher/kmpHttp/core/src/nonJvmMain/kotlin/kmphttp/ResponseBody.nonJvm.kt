/*
 * Copyright (C) 2014 Square, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package kmphttp

import kmpcommon.io.AsyncSource
import kmpcommon.io.readUtf8String
import kmpcommon.io.writeAll
import kmphttp.internal.DefaultIODispatcher
import kmphttp.internal.closeQuietly
import kotlinx.coroutines.withContext
import okio.Buffer
import okio.ByteString
import okio.Closeable
import okio.use

actual abstract class ResponseBody : Closeable {

    actual abstract fun contentType(): MediaType?

    actual abstract fun contentLength(): Long

    abstract fun asyncSource(): AsyncSource

    actual override fun close(): Unit = asyncSource().closeQuietly()

    actual companion object {
        actual val EMPTY: ResponseBody = object : ResponseBody() {
            override fun contentType(): MediaType? = null
            override fun contentLength(): Long = 0
            override fun asyncSource() = AsyncSource.EMPTY
        }
    }
}

actual fun ResponseBody.asyncSource(): AsyncSource {
    return this.asyncSource()
}

actual suspend fun ResponseBody.byteString(): ByteString = withContext(DefaultIODispatcher) {
    asyncSource().use { source ->
        val buffer = Buffer()
        buffer.writeAll(source)
        buffer.readByteString()
    }
}

actual suspend fun ResponseBody.utf8String() = withContext(DefaultIODispatcher) {
    this@utf8String.asyncSource().readUtf8String()
}
